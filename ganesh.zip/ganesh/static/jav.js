// let color = ["red","green","yellow","pink","black"]
let left = document.getElementById("left")
let right = document.getElementById("right")
const imageSelector = document.querySelectorAll(".image")
const image = document.getElementById("image")
let currentIndex = 0

 imageSelector[currentIndex+1].style.display = "none"

right.addEventListener("click",()=>{
  if(currentIndex < imageSelector.length - 1){
      imageSelector[currentIndex].style.display = "none"
      currentIndex++
      imageSelector[currentIndex].style.display = "block"
  }
  else{
        
         imageSelector[currentIndex].style.display = "none"
          currentIndex = 0
          imageSelector[currentIndex].style.display = "block"
  }
})


left.addEventListener("click",()=>{
   
  if(currentIndex < imageSelector.length - 1){
                                          
       imageSelector[currentIndex].style.display = "none"
       currentIndex = 1
       imageSelector[currentIndex].style.display = "block"
   }               
   else if(currentIndex >= imageSelector.length - 1){
       imageSelector[currentIndex].style.display = "none"
       currentIndex = 0
       imageSelector[currentIndex].style.display = "block"
   }
})






setInterval(()=>{

 if(currentIndex < imageSelector.length - 1){
      imageSelector[currentIndex].style.display = "none"
      currentIndex++
      imageSelector[currentIndex].style.display = "block"
      }
   else{
        
         imageSelector[currentIndex].style.display = "none"
          currentIndex = 0
          imageSelector[currentIndex].style.display = "block"
  }
//    let random = Math.floor(Math.random()*color.length)
//    let selectedColor = color[random]
//    console.log(selectedColor)
//    document.body.style.backgroundColor=selectedColor
},1000)



const submit = document.getElementById("submit")
const getDetails = document.getElementById("getDetails")
const search = document.getElementById("search")
const table = document.getElementById("table")

search.addEventListener("input",()=>{
    getDetails1()
})
submit.addEventListener("click",async()=>{
 const Pname = document.getElementById("Pname").value
 const Pquentity =document.getElementById("Pquentity").value

  let details = {
    productname :Pname,
    quentity : Pquentity
  }
   postData(details) 
})

async function postData(details){
    let response = await fetch("http://localhost:8080/api/details",{
          method:"POST",
          headers :{
            "Content-Type" : "application/json"
          },
          body : JSON.stringify(details)
    })
    let data = await response.json()
    console.log(data)     
}

getDetails.addEventListener("click",()=>{
   getDetails1()
})



async function getDetails1(){
    let response = await fetch("http://localhost:8080/api/details",{
        method:"GET",
        headers : {
            "Content-Type":"application/json"
        }
    })
  let data = await response.json()
  table.innerHTML = `
     <tr>
            <th>Product Name</th>
            <th>Product Quentity</th>
        </tr>
  `
  let filerData = data.filter(element => element.productname.toLowerCase().includes(search.value.toLowerCase()))
  filerData.forEach(element => {
     let tr = document.createElement("tr")
      let td1 = document.createElement("td")
      let td2 = document.createElement("td")
     td1.textContent = element.productname
     td2.textContent = element.quentity
      tr.append(td1,td2)
      table.appendChild(tr)

  });

}

 getDetails1()