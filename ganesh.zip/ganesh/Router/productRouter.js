const express = require("express")
const router = express.Router()
const {createEntry,findall} = require("../controller/productController")
router.post("/details",createEntry)
router.get("/details",findall)
module.exports = router