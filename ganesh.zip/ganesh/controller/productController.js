const {product111} = require("../models")

const createEntry = async(req,res)=>{
    let productdetails = await product111.create(req.body)
    res.send(productdetails)
}

const findall = async(req,res)=>{
    let productdetails = await product111.findAll()
    res.send(productdetails)
}


module.exports = {
    createEntry,
    findall
}