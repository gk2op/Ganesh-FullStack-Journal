const express = require("express")
const app = express()
const path = require("path")
const productRouter = require("./Router/productRouter")

app.use(express.json())
app.use(express.static("static"))

//query injection url
app.get("/pp",(req,res)=>{
    let data = req.query
    const {name , rollno} = data
    console.log(name ,rollno )
    res.send(data)
})

app.use("/api",productRouter)
//index.html pages sending to the browser
app.get("/index",(req,res)=>{

    res.sendFile(path.join(__dirname,"view","index.html"))

})




app.listen(8080,()=>{
    console.log("running")
})