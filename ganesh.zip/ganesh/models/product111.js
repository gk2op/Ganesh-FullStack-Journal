'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class product111 extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  product111.init({
    productname: DataTypes.STRING,
    quentity: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'product111',
  });
  return product111;
};